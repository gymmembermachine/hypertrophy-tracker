# Hypertrophy Tracker (GitHub Pages Bundle)

This folder is ready for GitHub Pages. Steps:

1) Create a repo on GitHub (public), e.g. `hypertrophy-tracker`.
2) Upload these files to the repo **root** (drag & drop via the web UI).
3) Rename `index.html` if needed (it must be exactly `index.html`).
4) In **Settings → Pages**: set **Branch** to `main`, **Folder** to `/ (root)`, Save.
5) Wait 1–2 minutes. Your site will be at: https://<your-username>.github.io/<repo-name>/

Notes
- All data stores in the browser (localStorage). Use the Export/Import tab for backups.
- You can add it to your phone’s Home Screen for app-like behavior.
